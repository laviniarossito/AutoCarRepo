
public class ClasseMotos extends ClasseAutomotores {
		
	// Extends + super
	public ClasseMotos (String corPar, String marcaPar, String modeloPar, String tipoPar){
		super(corPar, marcaPar, modeloPar, tipoPar);
	}
}