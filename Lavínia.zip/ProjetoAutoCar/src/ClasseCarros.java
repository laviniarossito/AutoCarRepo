
public class ClasseCarros extends ClasseAutomotores {
	
	int quantidadePortasAt;
	
	// Extends + super
	public ClasseCarros (String corPar, String marcaPar, String modeloPar, String tipoPar, int quantidadePortasPar){
		super(corPar, marcaPar, modeloPar, tipoPar);
		this.quantidadePortasAt = quantidadePortasPar;
	}
	
	//Getter
	public int pegarQuantidadePortas() {
		return quantidadePortasAt;
	}
	
	//Setter
	public void alterarQuantidadePortas(int quantidadePortasPar) {
		this.quantidadePortasAt = quantidadePortasPar;
	}

}