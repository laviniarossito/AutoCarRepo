
public class ClassePrincipal {

	public static void main(String[] args) {

	}

}
